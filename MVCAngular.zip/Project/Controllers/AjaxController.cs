﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using ArtistsRequest.Models;

namespace ArtistsRequest.Controllers
{
    public class AjaxController : Controller
    {
        // GET: Ajax
        public ActionResult Index()
        {
            return View();
        }
         [ChildActionOnly]
        public ActionResult VideoPlayer(int? messageId)
        {
            //List<Message> messages = new  List<Message>();

            Message ms = new Message();

            //ms.URL="https://www.youtube.com/watch?v=e7gqHwdPkRg&x-yt-ts=1421914688&x-yt-cl=84503534";
            ms.URL = "http://vimeo.com/originals/inthemoment/108833443";

            if (ms != null)
            {
                if (ms.URL != null)
                {
                    return PartialView("~/Views/AjaxViews/_VideoView.cshtml", ms);
                }

                ms.URL = "There was a problem loading video.";
                return PartialView("~/Views/AjaxViews/_VideoView.cshtml", ms);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }
    }
}