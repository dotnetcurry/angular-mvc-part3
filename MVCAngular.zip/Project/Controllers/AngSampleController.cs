﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Using_Angular.Controllers
{
        [Authorize]
    public class AngSampleController : Controller
    {
        // GET: AngSample
        public ActionResult Index()
        {
            return View();
        }

        // GET: AngSample/Details/5
        public ActionResult Details()
        {
            return PartialView("Details");
        }

        // GET: AngSample/Create
        public ActionResult Lists()
        {
            return PartialView("Lists");
        }

        // POST: AngSample/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: AngSample/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AngSample/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: AngSample/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AngSample/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
