﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Using_Angular.Views.ArtistInfo
{
    [Authorize]
    public class ArtistInfoController : Controller
    {
        // GET: ArtistInfo
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult addartist()
        {
            return PartialView("AddArtists");
        }

        public ActionResult showartists()
        {
            return PartialView("ShowArtists");
        }

        public ActionResult editartist()
        {
            return PartialView("EditArtist");
        }

        public ActionResult deleteartist()
        {
            return PartialView("DeleteArtist");
        }
    }
}