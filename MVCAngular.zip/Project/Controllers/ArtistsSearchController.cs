﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Michaels_Stuff;

namespace Michaels_Stuff.Models
{
     [Authorize]
    public class ArtistsSearchController : Controller
    {
       
        private KendallsoftEntity db = new KendallsoftEntity();

        // GET: ArtistsSearch
        public ActionResult Index(string BandNames, string searchString)
        {

            var GenreLst = new List<string>();

            var BandQry = from d in db.MyArtists
                           orderby d.BandName
                           select d.BandName;

            GenreLst.AddRange(BandQry.Distinct());
            ViewBag.BandNames = new SelectList(GenreLst);


            var Artists = from m in db.MyArtists
                         select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                Artists = Artists.Where(s => s.BandName.Contains(searchString));
                return View(Artists.ToList());
            }

            if (!string.IsNullOrEmpty(BandNames) && string.IsNullOrEmpty(searchString))
            {
                Artists = Artists.Where(x => x.BandName == BandNames);
                return View(Artists.ToList());
            }

            if (Artists.Count() > 0)
            {
                return View(Artists.ToList());
            }
            else
            {
                return View(db.MyArtists.ToList());
            }
            

            
        }

        // GET: ArtistsSearch/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artist artist = db.MyArtists.Find(id);
            if (artist == null)
            {
                return HttpNotFound();
            }
            return View(artist);
        }

        // GET: ArtistsSearch/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ArtistsSearch/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ArtistId,LastName,FirstName,BandName,FirstOnSeen")] Artist artist)
        {
            if (ModelState.IsValid)
            {
                db.MyArtists.Add(artist);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(artist);
        }

        // GET: ArtistsSearch/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artist artist = db.MyArtists.Find(id);
            if (artist == null)
            {
                return HttpNotFound();
            }
            return View(artist);
        }

        // POST: ArtistsSearch/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ArtistId,LastName,FirstName,BandName,FirstOnSeen")] Artist artist)
        {
            if (ModelState.IsValid)
            {
                db.Entry(artist).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(artist);
        }

        // GET: ArtistsSearch/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artist artist = db.MyArtists.Find(id);
            if (artist == null)
            {
                return HttpNotFound();
            }
            return View(artist);
        }

        // POST: ArtistsSearch/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Artist artist = db.MyArtists.Find(id);
            db.MyArtists.Remove(artist);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
