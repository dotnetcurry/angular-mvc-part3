﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Michaels_Stuff.Controllers
{
    public class CodeTesterController : Controller
    {
        // GET: CodeTester
        public ActionResult Index()
        {
            //return View();
            return Content("Test your code here");
        }
    }
}