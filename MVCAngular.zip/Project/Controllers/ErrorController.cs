﻿using System.Web.Mvc;

namespace Michaels_Stuff.Controllers
{
    public class ErrorController : Controller
    {
        public ViewResult NotFound()
        {
           
            ViewBag.Artists = string.Empty;
            //Response.StatusCode = 404;
            HandleErrorInfo info = new HandleErrorInfo(new System.Exception("Page Not Found"), "Error", "Notfound");

            return View("~/Views/Errors/Error_404.cshtml", info);
        }

        public ActionResult CriticalError()
        {
            return View("~/Views/Errors/Error.cshtml");
        }

        public ActionResult HeavyLoad(string error)
        {
            return View("~/Views/Errors/DbNotResponding.cshtml");
        }
    }
}