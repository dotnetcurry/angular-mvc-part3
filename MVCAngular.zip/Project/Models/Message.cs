﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ArtistsRequest.Models
{
    public class Message
    {
        public Message()
        {
            this.Rank = 0D;
            this.Likes = 1;
            this.Dislikes = 0;
            this.URL = "";
            
        }

        public int Id { get; set; }
        public string  URL { get; set; }
        public Nullable<short> Votes { get; set; }
        public string Name { get; set; }
        public System.DateTime Date { get; set; }
        public int Type { get; set; }
        public string Linkdescription { get; set; }
        public string Title { get; set; }
        public double Rank { get; set; }
        public string MessageContent { get; set; }
        public string Subverse { get; set; }
        public short Likes { get; set; }
        public short Dislikes { get; set; }
        public string Thumbnail { get; set; }
        public Nullable<System.DateTime> LastEditDate { get; set; }
       
        public double Views { get; set; }

    }
}