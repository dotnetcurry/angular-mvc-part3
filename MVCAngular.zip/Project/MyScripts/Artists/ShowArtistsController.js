﻿app.controller('ShowArtistsController', function ($scope, $location, artistsService, ShareData) {

    loadRecords();

    //Function to Load all Artists Records.   
    function loadRecords() {
        var promiseGetArtists = artistsService.getArtists();

        promiseGetArtists.then(function (pl) { $scope.Artists = pl.data },
              function (errorPl) {
                  $scope.error = 'failure loading Artists', errorPl;
              });
    }


    //Method to route to the addemployee
    $scope.addArtist= function () {
        $location.path("/addartist");
    }

    //Method to route to the editArtist
    //The ArtistNo passed to this method is further set to the ShareData
    //This value can then be used to communicate across the Controllers
    $scope.editArtist = function (ArtistNo) {
        ShareData.value = ArtistNo;
        $location.path("/editartist");
    }

    //Method to route to the deleteArtist
    //The ArtistNo passed to this method is further set to the ShareData
    //This value can then be used to communicate across the Controllers
    $scope.deleteArtist = function (ArtistNo) {
        ShareData.value = ArtistNo;
        $location.path("/deleteartist");
    }
});