﻿    var app = angular.module("ApplicationModule", ["ngRoute"]);

    //The Factory used to define the value to
    //Communicate and pass data across controllers

    app.factory("ShareData", function () {
        return { value: 0 }
    });

    //Defining Routing
    app.config(['$routeProvider','$locationProvider', function ($routeProvider,$locationProvider) {
        $routeProvider.when('/showemployees',
                            {
                                templateUrl: 'EmployeeInfo/ShowEmployees',
                                controller: 'ShowEmployeesController'
                            });

        $routeProvider.when('/showartists',
                           {
                               templateUrl: 'ArtistInfo/ShowArtists',
                               controller: 'ShowArtistsController'
                           });

        $routeProvider.when('/addemployee',
                            {
                                templateUrl: 'EmployeeInfo/AddNewEmployee',
                                controller: 'AddEmployeeController'
                            });
        $routeProvider.when("/editemployee",
                            {
                                templateUrl: 'EmployeeInfo/EditEmployee',
                                controller: 'EditEmployeeController'
                            });
        $routeProvider.when('/deleteemployee',
                            {
                                templateUrl: 'EmployeeInfo/DeleteEmployee',
                                controller: 'DeleteEmployeeController'
                            });

        $routeProvider.when('/Home',
                          {
                              templateUrl: 'Home/Index',
                              
                          });

        $routeProvider.when('/Home/Index',
                        {
                            templateUrl: 'Home/Index',

                        });

        $routeProvider.when('/Home/Logoff',
                         {
                             templateUrl: 'Home/Logoff',

                         });
        $routeProvider.when('/Home/Contact',
                       {
                           templateUrl: 'Home/Contact',

                       });
        $routeProvider.when('/Home/About',
                      {
                          templateUrl: 'Home/About',

                      });


        $routeProvider.when('/Account/Register',
                     {
                         templateUrl: 'Account/Register',

                     });
        $routeProvider.when('/Account/Login',
                   {
                       templateUrl: 'Account/Login',

                   });

        //$routeProvider.when('/Account/LogOffAngular',
        //          {
        //              templateUrl: 'Home/Index',

        //          });

        $routeProvider.otherwise(
                            {
                               
                                controller: "MainCtrl",
                                template: "<div></div>"
                            });
       // $locationProvider.html5Mode(true);
        $locationProvider.html5Mode(true).hashPrefix('!')
    }])
    .controller('MainCtrl',[ // <- Use this controller outside of the ng-view!
  '$rootScope','$window',
  function($rootScope,$window){
      $rootScope.$on("$routeChangeStart", function (event, next, current) {
          // next.$$route <-not set when routed through 'otherwise' since none $route were matched
          if (next && !next.$$route) {
              event.preventDefault(); // Stops the ngRoute to proceed with all the history state logic
              // We have to do it async so that the route callback 
              // can be cleanly completed first, so $timeout works too
              $rootScope.$evalAsync(function() {
                  next.redirectTo = 'http://localhost:11111/'
                  $window.location.href = next.redirectTo;
              });
          }
      });
  }
    ]);