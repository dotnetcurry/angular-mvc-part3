﻿angular.module('project', ['ngRoute', 'firebase'])

.value('fbURL', 'https://dazzling-torch-1306.firebaseio.com/')
.service('fbRef', function (fbURL) {
       
    var myDataRef = new Firebase(fbURL);

    function authDataCallback(authData) {
        if (authData) {
            console.log("User " + authData.uid + " is logged in with " + authData.provider);
        } else {
            console.log("User is logged out");
        }
    }
    // Register the callback to be fired every time auth state changes
    var ref = new Firebase(fbURL);
    ref.onAuth(authDataCallback);
    return ref;
})
.service('fbAuth', function ($q, $firebase, $firebaseAuth, fbRef) {
    var auth;
    return function () {
        if (auth) return $q.when(auth);
        var authObj = $firebaseAuth(fbRef);
        if (authObj.$getAuth()) {
            return $q.when(auth = authObj.$getAuth());
        }
        var deferred = $q.defer();
        authObj.$authAnonymously().then(function (authData) {
            auth = authData;
            deferred.resolve(authData);
        });
        return deferred.promise;
    }
})

.service('Projects', function ($q, $firebase, fbRef, fbAuth) {
    var self = this;
    this.fetch = function () {
        if (this.projects) return $q.when(this.projects);
        return fbAuth().then(function (auth) {
            var deferred = $q.defer();

            var projects = []
            projects[0] = { id:0, name: "TenDollar", site: "http://www.tendollartraining.com", description: "Affordable Training" }
            projects[1] = { id:1,name: "Angular", site: "https://angularjs.org/", description: "Angular" }
            projects[2] = { id:2,name: "Microsoft", site: "http://www.microsoft.com", description: "Microsoft Corporate" }
            projects[3] = { id:4,name: "Udemy", site:"http://www.udemy.com", description: "Udemy" }
           
            var ref = fbRef.child('projects/' + auth.auth.uid);
            var $projects = $firebase(ref);
            ref.on('value', function (snapshot) {
                if (snapshot.val() === null) {
                    //$projects.$set(window.projectsArray);

                    $projects.$set(projects);
                }
                //self.projects = snapshot.val();
                self.projects = $projects.$asArray();
                deferred.resolve(self.projects);
            });
            return deferred.promise;
        });
    };
})

.config(function ($routeProvider) {
    $routeProvider
      .when('/', {
          controller: 'ProjectListController as projectList',
          templateUrl: 'AngSample/lists',
          resolve: {
              projects: function (Projects) {
                  return Projects.fetch();
              }
          }
      })
      .when('/edit/:projectId', {
          controller: 'EditProjectController as editProject',
          templateUrl: 'AngSample/details'
      })
      .when('/new', {
          controller: 'NewProjectController as editProject',
          templateUrl: 'AngSample/details'
      })
      .otherwise({
          controller: "MainCtrl",
          template: "<div></div>"
      });
})

    .controller('MainCtrl',[ // <- Use this controller outside of the ng-view!
  '$rootScope','$window',
  function($rootScope,$window){
      $rootScope.$on("$routeChangeStart", function (event, next, current) {
          // next.$$route <-not set when routed through 'otherwise' since none $route were matched
          if (next && !next.$$route) {
              event.preventDefault(); // Stops the ngRoute to proceed with all the history state logic
              // We have to do it async so that the route callback 
              // can be cleanly completed first, so $timeout works too
              $rootScope.$evalAsync(function() {
                  next.redirectTo = 'http://localhost:11111/'
                  $window.location.href = next.redirectTo;
              });
          }
      });
      $locationProvider.html5Mode(true).hashPrefix('!')
  }

    ])


.controller('ProjectListController', function (projects) {
    var projectList = this;
    projectList.projects = projects;
})

.controller('NewProjectController', function ($location, Projects)
{
    var editProject = this;
    console.log(Projects.projects[0]);
    editProject.save = function () {
        console.log(editProject.project);

        var projects = []
        projects[0] = { id: 4, name: editProject.project.name, site: editProject.project.site, description: editProject.project.description }

        Projects.projects.push(projects[0]);
        Projects.projects.$save;
        console.log(Projects.projects);
        Projects.$save;
       //Projects.push(editProject.project).then(function (data) {
        $location.path('/');
       // });
    };
})

.controller('EditProjectController',
  function ($location, $routeParams, Projects) {
      var editProject = this;
      var projectId = $routeParams.projectId,
          projectIndex;

      editProject.projects = Projects.projects;
      projectIndex = editProject.projects.$indexFor(projectId);
      editProject.project = editProject.projects[projectIndex];

      editProject.destroy = function () {
          editProject.projects.$remove(editProject.project).then(function (data) {
              $location.path('/');
          });
      };

      editProject.save = function () {
          editProject.projects.$save(editProject.project).then(function (data) {
              $location.path('/');
          });
      };
  });