﻿var app = angular.module('ngArtistDemo', ['ngRoute'])
 .controller('ngAppDemoController',['$scope','artistsService',

 function ($scope, artistsService) {
    $scope.a = 1;
    $scope.b = 2;
    console.log("AngularJS is initialized and ready to go!");

    var artists = function (data) {
        $scope.Artists = data;
        //console.log($scope.Artists);
    };

    var errorDetails = function (serviceResp) {
        $scope.Error = "Something went wrong ??";
    };  

    artistsService.artists().then(artists, errorDetails);
   
 }])
 .controller('TenDollarController1', ['$scope',
 function ($scope) {
    $scope.a = 1;
    $scope.b = 2;
}])
.controller('TenDollarController2', ['$scope',
function ($scope) {
    $scope.name = "World";
}]);

app.factory("ShareData", function () {
    return { value: 0 }
});

app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
    $routeProvider
        .when("/Home", {
            templateUrl: "/Home.html",
            controller: "ngAppDemoController"
        });

    $routeProvider.when('/ArtistInfo/showartists',
                     {
                         templateUrl: 'ArtistInfo/ShowArtists',
                         controller: 'ShowArtistsController'
                     });

    $routeProvider.when('/ArtistInfo/addartist',
                   {
                       templateUrl: 'ArtistInfo/AddArtist',
                       controller: 'AddArtistController'
                   });

    $routeProvider.when('/addartist',
                 {
                     templateUrl: 'ArtistInfo/AddArtist',
                     controller: 'AddArtistController'
                 });

    $routeProvider.when('/editartist',
                  {
                      templateUrl: 'ArtistInfo/EditArtist',
                      controller: 'EditArtistController'
                  });
    $routeProvider.when('/deleteartist',
                 {
                     templateUrl: 'ArtistInfo/DeleteArtist',
                     controller: 'DeleteArtistController'
                 });


    $routeProvider.otherwise(
                             {
                               
                                 controller: "MainCtrl",
                                 template: "<div></div>"
                             });
    // $locationProvider.html5Mode(true);
    $locationProvider.html5Mode(true).hashPrefix('!')
}])
    .controller('MainCtrl',[ // <- Use this controller outside of the ng-view!
  '$rootScope','$window',
function($rootScope,$window){
    $rootScope.$on("$routeChangeStart", function (event, next, current) {
        // next.$$route <-not set when routed through 'otherwise' since none $route were matched
        if (next && !next.$$route) {
            event.preventDefault(); // Stops the ngRoute to proceed with all the history state logic
            // We have to do it async so that the route callback 
            // can be cleanly completed first, so $timeout works too
            $rootScope.$evalAsync(function() {
                next.redirectTo = 'http://mvcangdotcurry.azurewebsites.net'
                $window.location.href = next.redirectTo;
            });
        }
    });
}]);
