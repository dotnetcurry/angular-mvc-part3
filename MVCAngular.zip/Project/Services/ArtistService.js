﻿(function () {
    var artistsService = function ($http, $q, $log) {
        var cachedArtist;

        var artists = function () {
            return $http.get("/api/ArtistsAPI/")
                        .then(function (serviceResp) {
                            return serviceResp.data;
                        });
        };

        //Function to Read All Employees
        var getArtists = function () {
            return $http.get("api/ArtistsAPI/");
        };

        return {
            artists: artists,
            getArtists: getArtists
        };
    };
    var module = angular.module("ngArtistDemo");
    module.factory("artistsService", ["$http", "$q", "$log", artistsService]);
}());